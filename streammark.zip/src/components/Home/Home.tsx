function Home() {
  return (
    <section id="home" className="home-section">
      <h2>Welcome to StreamMark</h2>
      <p>Your hub for Educational Videos, Fun Facts, Movies, and Music.</p>
    </section>
  )
}
export default Home
