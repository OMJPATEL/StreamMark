function Header() {
  return (
    <header className="site-header">
      <h1>StreamMark</h1>
      {/* <p>Your hub for Educational, Fun-Facts, Movies & Music</p> */}
    </header>
  )
}
export default Header
